<p align="center">
    <img src="https://discord.c99.nl/widget/theme-4/832340116395655288.png" />
</p>

<p align="center">
    <img src="https://img.shields.io/github/followers/NashKK?label=Follow&style=social" alt="github followers" /><br>
    <br>
    <img src="https://github-readme-stats.vercel.app/api?username=NashKK&show_icons=true&theme=dark" alt="Leonnardo" />
    <img src="https://github-readme-stats.vercel.app/api/top-langs/?username=NashKK&theme=dark" alt="Leonnardo" />
   
</p>
<hr>

Discord: zSpl1nterUS_#6455

<br>

![JavaScript](https://img.shields.io/badge/-JavaScript-000000?style=for-the-badge&logo=javascript)
![HTML5](https://img.shields.io/badge/-HTML5-000000?style=for-the-badge&logo=HTML5)
![CSS3](https://img.shields.io/badge/-CSS3-000000?style=for-the-badge&logo=CSS3&logoColor=3799d6)


![Node.js](https://img.shields.io/badge/-Node.js-000000?style=for-the-badge&logo=node.js&logoColor=339933)

<hr>

  ![Snake animation](https://github.com/zSpl1nterUS/zSpl1nterUS/blob/output/github-contribution-grid-snake.svg)
